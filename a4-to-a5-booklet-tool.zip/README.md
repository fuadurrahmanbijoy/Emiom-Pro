# A4 -> A5 Booklet Print Tool

A local browser tool for converting an A4 PDF into a print-ready A5 booklet.

## Features

- Upload an A4 PDF by click or drag-and-drop.
- Booklet mode with automatic imposition.
- Adds blank pages so booklet pagination is a multiple of four.
- 2-up consecutive-page mode.
- Configurable safe margin.
- Calculates source pages, padded pages, A4 sheets, and scale.
- Exports a new landscape-A4 PDF designed for duplex booklet printing.
- Browser-side processing: the PDF is not uploaded to a server.

## Use

1. Open `index.html` in a modern browser while online.
2. Drop in the A4 PDF.
3. Keep **Booklet** selected for a folded A5 book.
4. Keep the safe margin at 3 mm initially.
5. Click **Build print-ready PDF**.
6. In the printer dialog, print the generated PDF at **Actual size / 100%**.
7. Use duplex printing and **short-edge binding** for the landscape sheets.
8. Fold each sheet in half and assemble in sheet order.

The web page uses CDN-hosted PDF.js/pdf-lib libraries. The user's PDF itself stays in the browser.
